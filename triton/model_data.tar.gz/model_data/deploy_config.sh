# deploy_config.sh

#注意 s3 路径最后加上 / 
S3_PATH="s3://a-web-uw2/test_triton/"
